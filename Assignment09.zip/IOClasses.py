#------------------------------------------#
# Title: IO Classes
# Desc: A Module for IO Classes
# Change Log: (Who, When, What)
# DBiesinger, 2030-Jan-01, Created File
# DBiesinger, 2030-Jan-02, Extended functionality to add tracks
# SHarms, 2022-Dec-10, Completed to dos
#------------------------------------------#

if __name__ == '__main__':
    raise Exception('This file is not meant to run by itself')

import DataClasses as DC
import ProcessingClasses as PC

class FileIO:
    """Processes data to and from file:

    properties:

    methods:
        save_inventory(file_name, lst_Inventory): -> None
        load_inventory(file_name): -> (a list of CD objects)

    """
    @staticmethod
    def save_inventory(file_name: list, lst_Inventory: list) -> None:
        """
        Args:
            file_name (list): list of file names [CD Inventory, Track Inventory] that hold the data.
            lst_Inventory (list): list of CD objects.

        Returns:
            None.
        """

        file_name_CD = file_name[0]
        file_name_trk = file_name[1]
        try:
            file_cd = open(file_name_CD, 'w')
            for disc in lst_Inventory:
                    file_cd.write(disc.get_record())
            file_trk = open(file_name_trk, 'w')
            for disc in lst_Inventory:
                tracks = disc.cd_tracks
                disc_id = disc.cd_id
                for trk in tracks:
                    if trk is not None:
                        record = '{},{}'.format(disc_id, trk.get_record())
                        file_trk.write(record)
        except:
            print('There was a general error!')

    @staticmethod
    def load_inventory(file_name: list) -> list:
        """
        Args:
            file_name (list): list of file names [CD Inventory, Track Inventory] that hold the data.

        Returns:
            list: list of CD objects.
        """

        lst_Inventory = []
        file_name_CD = file_name[0]
        file_name_trk = file_name[1]
        try:
            file_cd = open(file_name_CD, 'r')
            for line in file_cd:
                data = line.strip().split(',')
                row = DC.CD(data[0], data[1], data[2])
                lst_Inventory.append(row)
            file_trk = open(file_name_trk, 'r')
            for line in file_trk:
                data = line.strip().split(',')
                cd = PC.DataProcessor.select_cd(lst_Inventory, int(data[0]))
                track = DC.Track(int(data[1]), data[2], data[3])
                cd.add_track(track)
        except:
            print('There was a general error!')
        return lst_Inventory

class ScreenIO:
    """Handling Input / Output:
        properties
        methods:
            print_menu(): -> None
            menu_choice(): -> choices as a string
            print_CD_menu(): -> None
            menu_CD_choice(): -> submenu choices as a string
            show_inventory(table): -> None
            show_tracks(cd): -> None
            get_CD_info(): -> returns cdID, cdTitle, and CDArtists as strings
            get_track_info():-> returns trkID, trkTitle, and trkLength as strings
            """

    @staticmethod
    def print_menu():
        """Displays a menu of choices to the user

        Args:
            None.

        Returns:
            None.
        """

        print('Main Menu\n\n[l] load Inventory from file\n[a] Add CD / Album\n[d] Display Current Inventory')
        print('[c] Choose CD / Album\n[s] Save Inventory to file\n[x] exit\n')

    @staticmethod
    def menu_choice():
        """Gets user input for menu selection

        Args:
            None.

        Returns:
            choice (string): a lower case sting of the users input out of the choices l, a, d, c, s or x

        """
        choice = ' '
        while choice not in ['l', 'a', 'd', 'c', 's', 'x']:
            choice = input('Which operation would you like to perform? [l, a, d, c, s or x]: ').lower().strip()
            if choice not in ['l', 'a', 'd', 'c', 's', 'x']:
                print('Choose a valid letter from the menu options.')
        print()  # Add extra space for layout
        return choice

    @staticmethod
    def print_CD_menu():
        """Displays a sub menu of choices for CD / Album to the user

        Args:
            None.

        Returns:
            None.
        """

        print('CD Sub Menu\n\n[a] Add track\n[d] Display cd / Album details\n[r] Remove track\n[x] exit to Main Menu')

    @staticmethod
    def menu_CD_choice():
        """Gets user input for CD sub menu selection

        Args:
            None.

        Returns:
            choice (string): a lower case sting of the users input out of the choices a, d, r or x

        """
        choice = ' '
        while choice not in ['a', 'd', 'r', 'x']:
            choice = input('Which operation would you like to perform? [a, d, r or x]: ').lower().strip()
        print()  # Add extra space for layout
        return choice

    @staticmethod
    def show_inventory(table):
        """Displays current inventory table


        Args:
            table (list of dict): 2D data structure (list of dicts) that holds the data during runtime.

        Returns:
            None.

        """
        print('======= The Current Inventory: =======')
        print('ID\tCD Title (by: Artist)\n')
        for row in table:
            print(row)
        print('======================================')

    @staticmethod
    def show_tracks(cd):
        """Displays the Tracks on a CD / Album

        Args:
            cd (CD): CD object.

        Returns:
            None.

        """
        print('====== Current CD / Album: ======')
        print(cd)
        print('=================================')
        print(cd.get_tracks())
        print('=================================')

    @staticmethod
    def get_CD_info():
        """function to request CD information from User to add CD to inventory

        Returns:
            cdId (string): Holds the ID of the CD dataset.
            cdTitle (string): Holds the title of the CD.
            cdArtist (string): Holds the artist of the CD.
        """

        try:
            cdId = input('Enter ID: ').strip()
        except:
            print('Only integers are accepted here.')
        cdTitle = input('What is the CD\'s title? ').strip()
        cdArtist = input('What is the Artist\'s name? ').strip()
        return cdId, cdTitle, cdArtist

    @staticmethod
    def get_track_info():
        """function to request Track information from User to add Track to CD / Album

        Returns:
            trkId (string): Holds the ID of the Track dataset.
            trkTitle (string): Holds the title of the Track.
            trkLength (string): Holds the length (time) of the Track.
        """

        try:
            trkId = input('Enter Position on CD / Album: ').strip()
        except:
            print('Only integers are accepted as track IDs.')
        trkTitle = input('What is the Track\'s title? ').strip()
        trkLength = input('What is the Track\'s length? ').strip()
        return trkId, trkTitle, trkLength

